package kodlama.io.rentACarDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentACarDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
