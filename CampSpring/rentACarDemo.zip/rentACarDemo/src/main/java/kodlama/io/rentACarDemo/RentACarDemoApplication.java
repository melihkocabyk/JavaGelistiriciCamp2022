package kodlama.io.rentACarDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentACarDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentACarDemoApplication.class, args);
	}

}
